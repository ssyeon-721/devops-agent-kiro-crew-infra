import json
import boto3
import os
import logging
import urllib.request
import urllib.parse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

REGION        = os.environ['AWS_REGION_NAME']
SLACK_SECRET  = os.environ['SLACK_SECRET_ID']
SLACK_CHANNEL = os.environ['SLACK_CHANNEL_ID']

def get_bot_token():
    client = boto3.client('secretsmanager', region_name=REGION)
    resp = client.get_secret_value(SecretId=SLACK_SECRET)
    secret = json.loads(resp['SecretString'])
    return secret['SLACK_BOT_TOKEN']

def post_to_slack(token, channel, text):
    payload = json.dumps({
        "channel": channel,
        "text": text,
        "unfurl_links": False,
    }).encode('utf-8')
    req = urllib.request.Request(
        'https://slack.com/api/chat.postMessage',
        data=payload,
        headers={
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': f'Bearer {token}',
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        body = json.loads(resp.read())
    if not body.get('ok'):
        raise RuntimeError(f"Slack API error: {body.get('error')}")
    return body

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))

    token = get_bot_token()

    for record in event.get('Records', []):
        message_str = record['Sns']['Message']
        try:
            message = json.loads(message_str)
        except Exception:
            message = {"raw": message_str}

        detail_type      = message.get('detail-type', 'Unknown')
        detail           = message.get('detail', {})
        investigation_id = detail.get('metadata', {}).get('investigation_id', 'N/A')
        status           = detail.get('status', '')
        findings_summary = detail.get('findings', {}).get('summary', '')

        if detail_type == 'Investigation Completed':
            text = (
                f":white_check_mark: *DevOps Agent 조사 완료*\n"
                f">*Investigation ID:* `{investigation_id}`\n"
                f">*Status:* {status}\n"
                f">*Summary:* {findings_summary}"
            )
        elif detail_type == 'Investigation Failed':
            text = (
                f":x: *DevOps Agent 조사 실패*\n"
                f">*Investigation ID:* `{investigation_id}`\n"
                f">상세: {json.dumps(detail, ensure_ascii=False)[:400]}"
            )
        else:
            text = f":bell: *DevOps Agent 이벤트:* {detail_type}\n>{json.dumps(detail, ensure_ascii=False)[:400]}"

        result = post_to_slack(token, SLACK_CHANNEL, text)
        logger.info("Slack post result: %s", result)

    return {"statusCode": 200}
