import json
import boto3
import os
import logging
import urllib.request

logger = logging.getLogger()
logger.setLevel(logging.INFO)

REGION        = os.environ['AWS_REGION_NAME']
SLACK_SECRET  = os.environ['SLACK_SECRET_ID']
SLACK_CHANNEL = os.environ['SLACK_CHANNEL_ID']

def get_bot_token():
    client = boto3.client('secretsmanager', region_name=REGION)
    resp = client.get_secret_value(SecretId=SLACK_SECRET)
    return json.loads(resp['SecretString'])['SLACK_BOT_TOKEN']

def post_to_slack(token, payload):
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        'https://slack.com/api/chat.postMessage',
        data=data,
        headers={
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': f'Bearer {token}',
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        body = json.loads(resp.read())
    if not body.get('ok'):
        raise RuntimeError(f"Slack API error: {body.get('error')}")
    return body

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))
    token = get_bot_token()

    for record in event.get('Records', []):
        message_str = record['Sns']['Message']
        try:
            message = json.loads(message_str)
        except Exception:
            message = {"raw": message_str}

        detail_type      = message.get('detail-type', 'Unknown')
        detail           = message.get('detail', {})
        investigation_id = detail.get('metadata', {}).get('investigation_id', 'N/A')
        status           = detail.get('status', '')
        findings_summary = detail.get('findings', {}).get('summary', '')
        # 조치 정보 (DevOps Agent가 제안하는 remediation)
        remediation      = detail.get('findings', {}).get('remediation', '')
        namespace        = detail.get('metadata', {}).get('namespace', 'poc')
        deployment       = detail.get('metadata', {}).get('deployment_name', '')

        if detail_type == 'Investigation Completed':
            # Block Kit: 텍스트 + 승인 버튼
            action_value = json.dumps({
                "investigation_id": investigation_id,
                "namespace": namespace,
                "deployment": deployment,
                "channel": SLACK_CHANNEL,
            })
            blocks = [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": (
                            f":white_check_mark: *DevOps Agent 조사 완료*\n"
                            f">*Investigation ID:* `{investigation_id}`\n"
                            f">*Status:* {status}\n"
                            f">*Summary:* {findings_summary}"
                            + (f"\n>*Remediation:* {remediation}" if remediation else "")
                        )
                    }
                },
            ]
            # deployment 정보가 있을 때만 승인 버튼 추가
            if deployment:
                blocks.append({
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": f"✅ rollout undo ({deployment})"},
                            "style": "primary",
                            "action_id": "approve_rollback",
                            "value": action_value,
                            "confirm": {
                                "title": {"type": "plain_text", "text": "롤백 실행 확인"},
                                "text": {"type": "mrkdwn", "text": f"`kubectl rollout undo deployment/{deployment} -n {namespace}` 를 실행합니다."},
                                "confirm": {"type": "plain_text", "text": "실행"},
                                "deny": {"type": "plain_text", "text": "취소"},
                            }
                        },
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "❌ 무시"},
                            "action_id": "dismiss_action",
                            "value": investigation_id,
                        }
                    ]
                })
            payload = {"channel": SLACK_CHANNEL, "blocks": blocks, "text": f"DevOps Agent 조사 완료: {investigation_id}"}

        elif detail_type == 'Investigation Failed':
            payload = {
                "channel": SLACK_CHANNEL,
                "text": (
                    f":x: *DevOps Agent 조사 실패*\n"
                    f">*Investigation ID:* `{investigation_id}`\n"
                    f">상세: {json.dumps(detail, ensure_ascii=False)[:400]}"
                )
            }
        else:
            payload = {
                "channel": SLACK_CHANNEL,
                "text": f":bell: *DevOps Agent 이벤트:* {detail_type}\n>{json.dumps(detail, ensure_ascii=False)[:400]}"
            }

        result = post_to_slack(token, payload)
        logger.info("Slack post result ts=%s", result.get('ts'))

    return {"statusCode": 200}
