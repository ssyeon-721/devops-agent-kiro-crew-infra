import json
import boto3
import os
import logging
import urllib.request
import urllib.parse
import hmac
import hashlib
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)

REGION           = os.environ['AWS_REGION_NAME']
SLACK_SECRET     = os.environ['SLACK_SECRET_ID']
CREW_INSTANCE_ID = os.environ['CREW_INSTANCE_ID']
OPERATOR_ROLE    = os.environ['CREW_OPERATOR_ROLE_ARN']

def get_secrets():
    client = boto3.client('secretsmanager', region_name=REGION)
    resp = client.get_secret_value(SecretId=SLACK_SECRET)
    return json.loads(resp['SecretString'])

def verify_slack_signature(secrets, headers, body):
    """Slack 서명 검증 (리플레이 공격 방지 포함)"""
    signing_secret = secrets.get('SLACK_SIGNING_SECRET', '')
    if not signing_secret:
        logger.warning("SLACK_SIGNING_SECRET not set — skipping verification")
        return True
    ts = headers.get('x-slack-request-timestamp', '')
    sig = headers.get('x-slack-signature', '')
    if abs(time.time() - int(ts)) > 300:
        return False  # 5분 초과 리플레이
    base = f"v0:{ts}:{body}"
    expected = 'v0=' + hmac.new(signing_secret.encode(), base.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)

def post_to_slack(token, channel, text, thread_ts=None):
    payload = {"channel": channel, "text": text}
    if thread_ts:
        payload["thread_ts"] = thread_ts
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        'https://slack.com/api/chat.postMessage',
        data=data,
        headers={
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': f'Bearer {token}',
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())

def run_rollout_undo(namespace, deployment):
    """kirocrew-triage-operator 역할로 AssumeRole 후 rollout undo 실행"""
    sts = boto3.client('sts')
    assumed = sts.assume_role(
        RoleArn=OPERATOR_ROLE,
        RoleSessionName='h5-approver-rollback',
        DurationSeconds=900,  # 15분
    )
    creds = assumed['Credentials']

    cmd = (
        f"AWS_ACCESS_KEY_ID={creds['AccessKeyId']} "
        f"AWS_SECRET_ACCESS_KEY={creds['SecretAccessKey']} "
        f"AWS_SESSION_TOKEN={creds['SessionToken']} "
        f"kubectl rollout undo deployment/{deployment} -n {namespace} 2>&1"
    ) if deployment else (
        f"AWS_ACCESS_KEY_ID={creds['AccessKeyId']} "
        f"AWS_SECRET_ACCESS_KEY={creds['SecretAccessKey']} "
        f"AWS_SESSION_TOKEN={creds['SessionToken']} "
        f"kubectl get deployments -n {namespace} 2>&1"
    )

    ssm = boto3.client('ssm', region_name=REGION)
    resp = ssm.send_command(
        InstanceIds=[CREW_INSTANCE_ID],
        DocumentName='AWS-RunShellScript',
        Parameters={'commands': [
            f"sudo -u kirocrew -H bash -l -c \"{cmd}\""
        ]},
        Comment=f"H5 rollout undo {deployment}",
    )
    cmd_id = resp['Command']['CommandId']
    logger.info("SSM command sent: %s", cmd_id)

    # 최대 30초 대기
    import time as t
    for _ in range(6):
        t.sleep(5)
        result = ssm.get_command_invocation(
            CommandId=cmd_id,
            InstanceId=CREW_INSTANCE_ID,
        )
        if result['Status'] in ('Success', 'Failed', 'TimedOut', 'Cancelled'):
            return result['Status'], result.get('StandardOutputContent', '') + result.get('StandardErrorContent', '')

    return 'Pending', '(실행 중 — 결과는 잠시 후 확인하세요)'

def lambda_handler(event, context):
    logger.info("Received event keys: %s", list(event.keys()))

    # Function URL 요청 파싱
    headers  = {k.lower(): v for k, v in event.get('headers', {}).items()}
    raw_body = event.get('body', '')
    is_b64   = event.get('isBase64Encoded', False)
    if is_b64:
        import base64
        raw_body = base64.b64decode(raw_body).decode('utf-8')

    secrets = get_secrets()
    token   = secrets['SLACK_BOT_TOKEN']

    # 서명 검증
    if not verify_slack_signature(secrets, headers, raw_body):
        return {"statusCode": 401, "body": "Unauthorized"}

    # Slack payload 파싱
    parsed   = urllib.parse.parse_qs(raw_body)
    payload  = json.loads(parsed.get('payload', ['{}'])[0])
    logger.info("Slack payload type: %s", payload.get('type'))

    if payload.get('type') != 'block_actions':
        return {"statusCode": 200, "body": ""}

    action      = payload['actions'][0]
    action_id   = action.get('action_id', '')
    message_ts  = payload.get('message', {}).get('ts', '')
    channel_id  = payload.get('channel', {}).get('id', '')

    if action_id == 'dismiss_action':
        post_to_slack(token, channel_id,
                      ":white_check_mark: 무시됨 — 조치 없이 종료합니다.",
                      thread_ts=message_ts)
        return {"statusCode": 200, "body": ""}

    if action_id == 'approve_rollback':
        action_data = json.loads(action.get('value', '{}'))
        namespace   = action_data.get('namespace', 'poc')
        deployment  = action_data.get('deployment', '')
        inv_id      = action_data.get('investigation_id', '')

        post_to_slack(token, channel_id,
                      f":arrows_counterclockwise: `rollout undo {deployment}` 실행 중...",
                      thread_ts=message_ts)

        status, output = run_rollout_undo(namespace, deployment)
        output_trimmed = output.strip()[:600]

        if status == 'Success':
            msg = f":white_check_mark: *롤백 완료* (`{deployment}`, `{namespace}`)\n```{output_trimmed}```"
        else:
            msg = f":warning: *롤백 결과:* `{status}`\n```{output_trimmed}```"

        post_to_slack(token, channel_id, msg, thread_ts=message_ts)
        return {"statusCode": 200, "body": ""}

    return {"statusCode": 200, "body": ""}
